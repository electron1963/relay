#!/bin/bash
# get_relay_statuses.sh

# Replace these commands with the actual commands to check the relay statuses
relay_status_0=$(check_relay_status 0)  # should output 0x00 or 0x01
relay_status_1=$(check_relay_status 1)  # should output 0x00 or 0x01
relay_status_2=$(check_relay_status 2)  # should output 0x00 or 0x01
relay_status_3=$(check_relay_status 3)  # should output 0x00 or 0x01

echo "$relay_status_0 $relay_status_1 $relay_status_2 $relay_status_3"
