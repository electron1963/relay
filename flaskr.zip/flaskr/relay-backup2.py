from flask import Flask, render_template, request, redirect, url_for
import os

app = Flask(__name__)

# Initialize the relay statuses
relays = [False, False, False, False]

# Function to execute a command via SSH using os.system
def execute_remote_command(script_name):
    hostname = '192.168.0.127'
    ssh_command = f'ssh pi@{hostname} sudo /home/pi/{script_name}"'
    os.system(ssh_command)
    print(ssh_command)

@app.route('/')
def index():
    return render_template('index.html', relays=relays)

@app.route('/update_relay', methods=['POST'])
def update_relay():
    relay_id = int(request.form['relay_id'])
    action = request.form['action']
    print(relay_id)
    
    if action == 'on':
        relays[relay_id] = True
        # Execute remote script to turn relay on
        execute_remote_command(f'relay{relay_id}-on.sh')
    else:
        relays[relay_id] = False
        # Execute remote script to turn relay off
        execute_remote_command(f'relay{relay_id}-off.sh')
    
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
